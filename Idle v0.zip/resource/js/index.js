$('.sub-menu-tab').slick({
  dots: false,
  arrows: false,
  infinite: false,
  slidesToShow: 1,
  // slidesToScroll: 3,
  centerMode: false,
  swipeToSlide: true,
  variableWidth: true
});


